

/*
 * X2_Main.c
 *
 *  Created on: Dec 2, 2024
 *      Author: Terrence Jackson
 *      Purpose: Main Function to exercise multiplication and division functions
 */

#include "X2.h"

int main(){
	
	// Declare variable for functions
	int n = 16, d = 5;
	int x = 5, y = 5; 

	//Print division and multiplication results 
	printf("This is the result of dividing %d into %d: %d\n", n, d, idiv(n, d));
	printf("The product of multiplying %d and %d: %d\n", x, y, imul(x, y));

	return 0;
}
