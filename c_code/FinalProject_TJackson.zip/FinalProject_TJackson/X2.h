/*
 * X2.h
 *
 *  Created on: Dec 2, 2024
 *      Author: Terrence Jackson
 *      Purpose: Header file containing function declarations
 */

#include <stdio.h>

int imul(int x, int y);

int idiv(int n, int d);
